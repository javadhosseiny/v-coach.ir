<?php
$RunTop=1;
require_once 'topmain.php';
//?state=eyJjb25maWdfaWQiOiI4In0%3D&code=4/0Ab32j90A5MR53U2bucqi5_hCIcLfY_bG084un7g6gVvT4iwtkR9OfjPKTLZQbMP5CnDhYg&scope=https://www.googleapis.com/auth/youtube.upload
//var_dump($_GET);var_dump($_POST);exit;

if ( (!isset($_GET['code'])) or (!isset($_GET['state'])) ) {	
    ShowMessage("کد تایید گوگل جهت ارسال ویدئو به یوتوب دریافت نشد",1);		   
}
$code   = $_GET['code'];
$state  = $_GET['state'];
$state_data = json_decode(base64_decode($state), true);
if (!isset($state_data['config_id'])) {   
    ShowMessage("پارامتر ارسالی از سمت گوگل جهت شناسایی شماره رکورد صحیح نمی باشد",1);		   
}
$config_id = $state_data['config_id'];
$query  = pdo_query("select * from `messenger_list` where id='$config_id'");
$row    = pdo_fetch($query);
if ($row=='') {    ShowMessage("رکورد موردنظر جهت تنظیمات اتصال به یوتوب یافت نشد",1);		  }
$client_id          = $row['yotube_client_id'];
$client_secret      = $row['yotube_client_secret'];
$redirect_uri       = rtrim($sitenamelink, "/") . "/register-youtube/";  
$proxyFullAddress   = $row['proxy_url'];
$proxyAccount       = $row['proxy_account'];
$proxyType          = $row['proxy_type'];

//var_dump($_GET);var_dump($row);
// تبدیل code به access_token + refresh_token
$ch = curl_init("https://oauth2.googleapis.com/token");

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query([
        "code" => $code,
        "client_id" => $client_id,
        "client_secret" => $client_secret,
        "redirect_uri" => $redirect_uri,
        "grant_type" => "authorization_code"
    ])
]);
//--------------------------------------------
//--------------------------------------------
// تنظیمات عمومی پروکسی
/*
if ($proxyFullAddress!='') {
    curl_setopt($ch, CURLOPT_PROXY, $proxyFullAddress);
    curl_setopt($ch, CURLOPT_PROXYTYPE, $proxyType);
    if (!empty($proxyAccount)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyAccount);
    }
}
*/
$response   = curl_exec($ch);
$httpCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err        = @curl_error($ch);
curl_close($ch);
// بررسی خطاها و خروجی
if ($err) {    ShowMessage33("خطای cURL در ارسال پیام: $err - httpCode=$httpCode",1);		  }

$data       = json_decode($response, true);
if ($data === null) {    ShowMessage33("خطا: پاسخ نامعتبر از سرور یوتوب <BR> $response ",1);    }

// ذخیره refresh_token در دیتابیس
if (!isset($data['refresh_token'])) {
    ShowMessage33("کد توکن از گوگل جهت اتصال به یوتوب دریافت نشد <BR> $response ",1);    
}
$refresh_token = $data['refresh_token'];
//$query  = pdo_query("update `setting` set youtube_token='$refresh_token' ");
$query  = pdo_query("update `messenger_list` set bot_token='$refresh_token' where id='$config_id' ");
//--------------------------------------------
//--------------------------------------------
ShowMessage33("کد توکن از سایت گوگل دریافت شد<BR> <a href='/admin1354/?page=350'> بازگشت به صفحه مدیریت</a>", 1,'success');
exit;

//-----------------------------------------------------------------
/// show message without boostrap
function ShowMessage33($message, $OkExit=0, $colorType='danger') {
//    $message = htmlspecialchars(nl2br($message), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
	
    // تعیین رنگ پس‌زمینه مشابه Bootstrap
    switch($colorType) {
        case 'success':
            $bg = '#28a745'; // سبز
            break;
        case 'warning':
            $bg = '#ffc107'; // زرد
            break;
        case 'info':
            $bg = '#17a2b8'; // آبی
            break;
        case 'primary':
            $bg = '#007bff'; // آبی پررنگ
            break;
        case 'dark':
            $bg = '#343a40'; // تیره
            break;
        default:
            $bg = '#dc3545'; // danger (قرمز)
    }

    echo "
	<html>
	<head></head>
	<body dir='rtl'>
    <div style='width:100%;display:flex; justify-content:center; margin-top:40px; margin-bottom:40px; auto'>
        <div style='width:75%;background:$bg;border-radius:6px;padding:20px;color:#fff;text-align:center;
            font-family:Tahoma, sans-serif;font-size:16px; white-space:pre-wrap; word-wrap: break-word; overflow-wrap: break-word; word-break: break-word;'>
            $message
        </div>
    </div>
	</body>
	</html>
    ";

    if ($OkExit != 0) {
        exit;
    }
}

